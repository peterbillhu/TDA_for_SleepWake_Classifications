clear; clc;

cd Table_1_Subject_Normalization;
Generate_Table_1;
cd ..;

cd Table_2_Subject_Normalization;
Generate_Table_2;
cd ..;

cd Table_3_Subject_Normalization;
Generate_Table_3;
cd ..;

cd SI_Table_1_2_Subject_Normalization;
Generate_SI_Table_1_2;
cd ..;

cd SI_Table_3_4_Subject_Normalization;
Generate_SI_Table_3_4
cd ..;

cd SI_Table_5_6_Subject_Normalization;
Generate_SI_Table_5_6;
cd ..;

cd SI_Table_7_8_9_Subject_Normalization;
Generate_SI_Table_7_8_9;
cd ..;

cd SI_Table_10_11_12_Subject_Normalization;
Generate_SI_Table_10_11_12;
cd ..;

cd SI_Table_13_14_15_Subject_Normalization;
Generate_SI_Table_13_14_15;
cd ..;

cd SI_Table_16_17_Subject_Normalization;
Generate_SI_Table_16_17;
cd ..;

cd SI_Table_18_19_Subject_Normalization;
Generate_SI_Table_18_19;
cd ..;